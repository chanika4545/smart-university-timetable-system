window.Attendance={percent:x=>x.held?Math.round(x.attended/x.held*1000)/10:0,average(){let a=UNIVERSITY_DATA.attendance;return Math.round(a.reduce((s,x)=>s+this.percent(x),0)/a.length*10)/10}};
