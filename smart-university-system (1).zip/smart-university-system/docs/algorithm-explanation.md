# Algorithm Explanation

## Scheduling model
Each subject expands into the required number of weekly class meetings. A candidate assignment is `(day, time slot, classroom)`.

## Sorting
Classes are ordered by scheduling difficulty before allocation. Higher priority, larger class size and higher weekly frequency are handled first. The C engine uses insertion sort so the sorting algorithm is explicit for DAA demonstration.

## Greedy assignment
For the current class, candidates are tried deterministically: earliest day, earliest time slot, then smallest classroom that satisfies capacity. A candidate is accepted only if all constraints pass.

## Conflict detection
The engine rejects a candidate for insufficient capacity, unavailable teacher, teacher collision, room collision or batch collision.

## Backtracking
Scheduling is recursive. If a later class has no candidate, the current recursive branch returns failure. The preceding assignment is undone and the next candidate is tried. Therefore backtracking is executable logic, not documentation-only pseudocode.

## Searching
The C engine contains linear searches for subjects and classrooms. The browser UI supports live searching of master-data tables.

## Complexity
For C class meetings and K = D*S*R candidate combinations, a greedy scan with linear conflict checking is approximately O(C*K*C). Backtracking is exponential in the worst case because it may explore combinations of candidates. This is normal for constraint satisfaction problems.
